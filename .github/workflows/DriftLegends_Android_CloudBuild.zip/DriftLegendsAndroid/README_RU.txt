DRIFT LEGENDS 3D — Android project with cloud APK build

This ZIP contains your HTML game wrapped in an Android WebView app.
It also includes a GitHub Actions workflow to build an APK in the cloud.

IMPORTANT:
- This ZIP is an Android project, NOT an APK.
- The game loads Three.js from jsDelivr, so internet is required when launching.
- The first build is a debug APK, suitable for testing on your own device.

BUILD WITHOUT A PC (using your tablet):
1. Create/sign in to a GitHub account in your browser.
2. Create a NEW empty repository. Give it a name such as DriftLegends.
3. Extract this ZIP on your tablet.
4. Upload the CONTENTS of the extracted folder to the repository (including the hidden .github folder).
5. Open the repository's Actions tab.
6. Select "Build Android APK" and press "Run workflow".
7. When it finishes, open the completed workflow run, scroll to Artifacts, and download "DriftLegends-debug-apk".
8. Extract the downloaded artifact ZIP; inside is app-debug.apk. Tap it to install. Android may ask permission to install apps from that browser/file manager.

If GitHub's mobile website hides the Actions workflow, use the browser menu and choose Desktop site.
